from flask import Flask, request, jsonify
from flask_cors import CORS # type: ignore
import joblib
import pandas as pd


app = Flask(__name__)
CORS(app)

data = pd.read_csv('recipes.csv') 
knn = joblib.load('knn_model.pkl')
scaler = joblib.load('scaler.pkl')
@app.route('/enviar_datos', methods=['POST'])
def post():
    try:
        input_data = request.json
        peso = input_data.get('peso', None)
        altura = input_data.get('altura', None)
        edad = input_data.get('edad', None)
        genero = input_data.get('genero', None)
        act_fisica = input_data.get('act_fisica', None)
        objetivo = input_data.get('objetivo', None)
    except ValueError:
        return jsonify({"error": "Datos inválidos o fuera de rango"}), 400
    
    # Validar los campos 
    if not all([peso, altura, genero, act_fisica, objetivo]):
        return jsonify({"error": "Faltan datos o algunos campos están vacíos"}), 400

    #Calculo harris bennedict
    if genero == 1:  # Hombre
        tmb = (66 + (13.7 * peso) + (5 * altura) - (6.8 * edad)) * act_fisica
    else:  # Mujer
        tmb = (65 + (9.6 * peso) + (1.8 * altura) - (4.7 * edad)) * act_fisica

    if objetivo == 'S':  # Subir de peso
        calorias_finales = tmb + 500
        porcentaje_prot = 0.20  #15-25%
        porcentaje_carb = 0.525  #45-60%
        porcentaje_fat = 0.275  #20-30%
    elif objetivo == 'M':  # Mantener peso
        calorias_finales = tmb
        porcentaje_prot = 0.20  #15-25%
        porcentaje_carb = 0.525  #45-60%
        porcentaje_fat = 0.275  #20-35%
    else:  # Bajar de peso
        calorias_finales = tmb - 500
        porcentaje_prot = 0.30  #25-35%
        porcentaje_carb = 0.425  #35-50%
        porcentaje_fat = 0.25  #20-30%
   
    #dependiendo de las calorias aplicar los porcentajes de proteinas grasas y carbohidratos
    Proteinas = (calorias_finales * porcentaje_prot)/4
    Carbohidratos = (calorias_finales * porcentaje_carb)/4
    Grasas = (calorias_finales * porcentaje_fat)/9

    #dividir los gramos diarios de macronutrientes en las 3 comidas del dia
    comidas = {
        "1desayuno": {
            "proteinas": (Proteinas * 0.3),
            "grasas": (Grasas * 0.3),
            "carbohidratos": (Carbohidratos * 0.3),
        },
        "2almuerzo": {
            "proteinas": (Proteinas * 0.4),
            "grasas": (Grasas * 0.4),
            "carbohidratos": (Carbohidratos * 0.4),
        },
        "3cena": {
            "proteinas": (Proteinas * 0.3),
            "grasas": (Grasas * 0.3),
            "carbohidratos": (Carbohidratos * 0.3),
        }
    }
    recetas_usadas = set()
    # Función para obtener recomendaciones usando el modelo KNN
    def obtener_recomendaciones(prot, carb, fat, n_recommendations=1):
        input_data = pd.DataFrame([[prot, carb, fat]], columns=['Protein', 'Carbs', 'Fat'])
        input_scaled = scaler.transform(input_data)
        distances, indices = knn.kneighbors(input_scaled, n_neighbors=n_recommendations)
        if len(indices[0]) == 0:
            return []  # No se encontraron vecinos
        recomendaciones = []
          
        recommended_recipes = data.iloc[indices[0]]
        for i, (_, row) in enumerate(recommended_recipes.iterrows()):
           # if row['Recipe_name'] not in recetas_usadas:  # Verifica si ya fue recomendada
                recomendaciones.append({
                    'nombre': row['Recipe_name'],
                    'proteinas': row['Protein'],
                    'carbohidratos': row['Carbs'],
                    'grasas': row['Fat'],
                    'distancia': distances[0][i],
                })
          #  recetas_usadas.add(row['Recipe_name'])
        return recomendaciones

    recomendaciones_por_comida = {}
    for comida, valores in comidas.items():
        prot, carb, fat = valores['proteinas'], valores['carbohidratos'], valores['grasas']
        recomendaciones_por_comida[comida] = obtener_recomendaciones(prot, carb, fat)

    respuesta = {
        "caloriasDiariasRecomendadas": calorias_finales,
        "RecomendacionesRecetas": recomendaciones_por_comida,
        "mensaje": "hola gracias por preferirnos"
    }
    return jsonify(respuesta)

if __name__ == '__main__':
    app.run(debug=True)