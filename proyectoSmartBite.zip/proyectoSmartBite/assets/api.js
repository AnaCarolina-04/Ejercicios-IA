async function consumoApi() {
    // Obtener los valores de los campos del formulario
    const Peso = document.getElementById("peso").value;
    const Altura = document.getElementById("altura").value;
    const Edad = document.getElementById("edad").value;
    const Genero = document.getElementById("genero").value;
    const Act_fisica = document.getElementById("actividad").value;
    const Objetivo = document.getElementById("objetivo").value;

    // Crear el objeto de datos para enviar a la API
    const data = {
        peso: parseFloat(Peso),
        altura: parseInt(Altura),
        edad: parseInt(Edad),
        genero: parseInt(Genero),
        act_fisica: parseFloat(Act_fisica),
        objetivo: Objetivo
    };

    try {
        // Hacer la solicitud a la API
        const response = await fetch('http://127.0.0.1:5000/enviar_datos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        // Validar la respuesta
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error desconocido en el servidor');
        }

        // Procesar la respuesta JSON
        const result = await response.json();
        // Verificar en qué página estamos (calorías o recetas)
        if (window.location.pathname.includes("alories.html")) {
            // Mostrar solo calorías
            document.getElementById('respuesta').innerHTML = `
        <h4>Calorías diarias recomendadas:</h4>
        <p>${result.caloriasDiariasRecomendadas.toFixed(2)} calorías</p>
    `;
        } else if (window.location.pathname.includes("recetas.html")) {
            // Mostrar solo recetas
            document.getElementById('respuesta').innerHTML = `
        <h4>Recomendaciones de recetas:</h4>
        <ul>
            ${Object.entries(result.RecomendacionesRecetas)
                    .map(([comida, recetas]) =>
                        `<li><b>${comida}:</b>
                        ${recetas.length > 0
                            ? `<ul>${recetas.map(r =>
                                `<li>${r.nombre} - 
                                    Proteínas: ${r.proteinas}g, 
                                    Carbohidratos: ${r.carbohidratos}g, 
                                    Grasas: ${r.grasas}g
                                </li>`).join('')}</ul>`
                            : 'Sin recomendaciones disponibles'
                        }
                    </li>`).join('')}
        </ul>
    `;
        }
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('respuesta').innerHTML = `
    <div style="color: red;">
        Ocurrió un error: ${error.message}
    </div>
`;
    }
}